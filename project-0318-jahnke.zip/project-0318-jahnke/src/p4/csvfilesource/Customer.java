package p4.csvfilesource;

public class Customer {
   public int getValue(int i1, int i2) {
      int value = 0;
      value = i1 + i2;
      return value;
   }
}
